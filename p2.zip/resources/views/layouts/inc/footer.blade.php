
      <footer id="footer">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <ul class="social-icons">
                <li><a href="https://www.facebook.com/Al.Nazre.Real" target="_blank">Facebook</a></li>
                <li><a href="https://www.linkedin.com/in/al-nazre-real-9007a2123/" target="_blank">Linkedin</a></li>
              </ul>
            </div>
            <div class="col-lg-12">
              <div class="copyright-text">
                <p>&copy; Copyright 2022.
                      
                  | Designed by: <a rel="nofollow" href="https://www.linkedin.com/in/al-nazre-real-9007a2123/" target="_blank">Al Nazre Real</a></p>
              </div>
            </div>
          </div>
        </div>
        
      </footer>
