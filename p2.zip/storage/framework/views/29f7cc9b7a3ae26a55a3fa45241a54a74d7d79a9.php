<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <title>BlogSite</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/bootstrap5.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom.css')); ?>">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/templatemo-stand-blog.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.css')); ?>">


  </head>

  <body>

      

        <?php echo $__env->make('layouts.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">

          <?php if(($errors->any())): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e($error); ?>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>
        
        
          <div id="main">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
     
        <div id="footer">
          <?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    
      




        <!-- Bootstrap core JavaScript -->
    <script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
    
    <?php echo $__env->make('layouts.inc.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- Additional Scripts -->
   <script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/owl.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/slick.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/isotope.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/accordions.js')); ?>"></script>


      </body>
</html><?php /**PATH F:\Work 2021\Projects\BlogSite\resources\views/layouts/master.blade.php ENDPATH**/ ?>