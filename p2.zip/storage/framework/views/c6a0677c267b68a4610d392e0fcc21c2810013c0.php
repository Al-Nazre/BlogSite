
<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
              
                <h2>Post of <?php echo e($post->slug); ?></h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <section class="blog-posts mb-3 grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="all-blog-posts">
            <div class="card p-3">
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('storage/uploads/'.$post->image)); ?>" alt="" width="100%" height="auto">
                    </div>
                    <div class="col-md-6">
                      <a href="<?php echo e(url('post/'.$post->slug)); ?>"><h4><?php echo e($post->title); ?></h4></a>
                      <a href="<?php echo e(url('post/'.$post->slug)); ?>"><h5 class="font-weight-bold text-warning"><?php echo e($post->slug); ?></h5></a>
                      <p ><?php echo e($post->body); ?></p>
                    </div>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Work 2021\Projects\BlogSite\resources\views/post/slug.blade.php ENDPATH**/ ?>