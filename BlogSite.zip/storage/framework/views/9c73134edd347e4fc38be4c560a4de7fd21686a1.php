
<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4>Recent Posts</h4>
                <h2>Our Recent Blog Entries</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <section class="blog-posts grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="all-blog-posts">
              <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="<?php echo e(asset('storage/uploads/'.$post->image)); ?>" height="100%" width="auto" alt="">
                    </div>
                    <div class="down-content">
                      <a href="<?php echo e(url('post/'.$post->slug)); ?>"><span><?php echo e($post->slug); ?></span></a>
                      <a href="<?php echo e(url('post/'.$post->slug)); ?>"><h4><?php echo e($post->title); ?></h4></a>
                      <p ><?php echo e($post->body); ?></p>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <center>
      <div class="wrapper">
        <span>
            <?php echo e($posts->links()); ?>

        </span>
      </div>
    </center><br><br><br>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Work 2021\Projects\BlogSite\resources\views/welcome.blade.php ENDPATH**/ ?>