

<?php $__env->startSection('content'); ?>
<div class="container">
  <h3 class="text-center m-3"><?php echo e($user->name); ?>'s Posts</h3>
  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="m-3">
    <div class="p-3 card rounded ">
      <div class="row mb-3">
        <div class="col-md-3 col-12">
          <img class="img-post" src="storage/uploads/<?php echo e($item->image); ?>" alt="Image" name="image">
        </div>
        <div class="col-md-9 col-12 text-center">
          <h5><?php echo e($item->title); ?></h5>
          <small><?php echo e($item->body); ?></small>
        </div>
      </div>
      <center>
        
        <a href="<?php echo e(url('edit-post-'.$item->id)); ?>" class ="text-light"><button class="btn btn-warning" >EDIT</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="<?php echo e(url('delete-post/'.$item->id)); ?>" class="btn btn-danger" >DELETE</a>
      </center>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
 <center>
      <div class="wrapper">
        <span>
            <?php echo e($posts->links()); ?>

        </span>
      </div>
    </center><br><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Work 2021\Projects\BlogSite\resources\views/post/index.blade.php ENDPATH**/ ?>