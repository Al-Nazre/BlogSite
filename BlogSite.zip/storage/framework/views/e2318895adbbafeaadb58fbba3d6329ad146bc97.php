<?php if(auth()->guard()->guest()): ?>
<section class="navigation shadow-lg">
  <div class="nav-container">
    <div class="brand">
      <a href="/">Blog Site</a>
    </div>
    <nav class="nav">
      <div class="nav-mobile"><a id="navbar-toggle"><span class="text-dark"></span></a></div>
      <center>
        <ul class="nav-list">
            <li>
            <a  href="/">Home</a>
            </li>
            <li>
            <a href="<?php echo e(url('login')); ?>">Login</a>
            </li>
            <li>
            <a href="<?php echo e(url('register')); ?>">Register</a>
            </li>
        </ul>
    </center>
    </nav>
  </div>
</section>
<?php else: ?>
<section class="navigation">
  <div class="nav-container">
    <div class="brand">
      <a href="home">Blog Site</a>
    </div>
    <nav class="nav">
      <div class="nav-mobile"><a id="navbar-toggle"><span class="text-dark"></span></a></div>
      <center>
        <ul class="nav-list">
            <li>
            <a  href="<?php echo e(url('home')); ?>">Home</a>
            </li>
            <li>
            <a href="<?php echo e(url('post-create')); ?>">Add Post</a>
            </li>
            <li>
            <a href="<?php echo e(url('post')); ?>">My Posts</a>
            </li>
            <li>
            <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">Logout</a><form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
            </li>
        </ul>
    </center>
    </nav>
  </div>
</section>
<?php endif; ?>
<?php /**PATH F:\Work 2021\Projects\BlogSite\resources\views/layouts/inc/nav.blade.php ENDPATH**/ ?>